package com.webdev.tinder.user;

public enum Role {
    USER,
    ADMIN
}
